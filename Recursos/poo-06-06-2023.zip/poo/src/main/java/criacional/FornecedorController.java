package criacional;

import java.util.ArrayList;
import java.util.Calendar;

public final class FornecedorController {
    private static FornecedorController instance;
    private ArrayList<Fornecedor> fornecedores;

    private Integer idFornecedor = 1;
    private FornecedorController(){
        System.out.println("Iniciando o cadastro de fornecedores");
        fornecedores = new ArrayList<>();
    }
    public static FornecedorController getInstance(){
        if(instance==null){
            instance = new FornecedorController();
        }
        return instance;
    }
    public void cadastrar(Fornecedor fornecedor){
        if(buscarPorCNPJ(fornecedor.getCnpj())==null){
            fornecedor.setId(idFornecedor);
            fornecedores.add(fornecedor);
            idFornecedor++;
            System.out.println("Fornecedor cadastrado com sucesso: " + fornecedor.getCnpj());
        }else{
            System.out.println("Fornecedor já cadastrado: " + fornecedor.getCnpj());
        }
    }
    public Fornecedor buscarPorCNPJ(String cnpj){
        for (Fornecedor f: fornecedores) {
            if(f.getCnpj().equals(cnpj)){
                return f;
            }
        }

        return null;
    }


}
