package criacional;

public class FornecedorBuilder {
    private Fornecedor fornecedor;
    public FornecedorBuilder(){
        fornecedor = new Fornecedor();
    }
    public FornecedorBuilder addCpnj(String cnpj){
        this.fornecedor.setCnpj(cnpj);
        return this;
    }
    public FornecedorBuilder addNomes(String razaoSocial, String nomeFantasia){
        this.fornecedor.setRazaoSocial(razaoSocial);
        this.fornecedor.setNomeFantasia(nomeFantasia);
        return this;
    }
    public FornecedorBuilder addContato(String telefone, String email){
        this.fornecedor.setTelefone(telefone);
        this.fornecedor.setEmail(email);
        return this;
    }
    public FornecedorBuilder addEndereco(String logradouro,
                                         String numero,
                                         String cep,
                                         String bairro,
                                         String cidade,
                                         String estado){
        if(this.fornecedor.getEndereco()==null) {
            this.fornecedor.setEndereco(new Endereco());
        }
        Endereco endereco = this.fornecedor.getEndereco();
        endereco.setLogradouro(logradouro);
        endereco.setNumero(numero);
        endereco.setCep(cep);
        endereco.setBairro(bairro);
        endereco.setCidade(cidade);
        endereco.setEstado(estado);

        return this;
    }

    public FornecedorBuilder addComplementoEndereco(String complemento){
        if(this.fornecedor.getEndereco()==null) {
            this.fornecedor.setEndereco(new Endereco());
        }
        this.fornecedor.getEndereco().setComplemento(complemento);
        return this;
    }

    public Fornecedor build() throws Exception{
        if(this.fornecedor.getCnpj()==null || this.fornecedor.getCnpj().isBlank()){
            System.out.println("Obrigatório CPNJ");
            throw new Exception("Obrigatório CPNJ para cadastrar Fornecedor");
        }
        return this.fornecedor;
    }
}












