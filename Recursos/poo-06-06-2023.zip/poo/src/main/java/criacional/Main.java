package criacional;

public class Main {
    public static void main(String[] args) {
        FornecedorController fornecedorController = FornecedorController.getInstance();
        Fornecedor f1 = new Fornecedor();
        f1.setCnpj("123456879");
        f1.setEmail("ifsc@ifsc.edu.br");
        f1.setNomeFantasia("Instituto Federal de Santa Catarina");
        f1.setRazaoSocial("Instituto Federal de Educação Básica, Técnica e Tecnológica...");
        f1.setTelefone("47422233232");
        Endereco endereco = new Endereco();
        endereco.setComplemento("complemento");
        endereco.setEstado("SC");
        endereco.setBairro("Bela Vista");
        endereco.setNumero("123");
        endereco.setCidade("Gaspar");
        endereco.setLogradouro("Afonso pena");
        f1.setEndereco(endereco);




        try {
            Fornecedor f2 = new FornecedorBuilder().
                    addContato("47422233232","ifsc@ifsc.edu.br").
                    addCpnj("123456789").
                    addNomes("Instituto Federal de Educação Básica, Técnica e Tecnológica...",
                            "Instituto Federal de Santa Catarina").
                    addEndereco("Afonso pena","123","8999999","Bela Vista","Gaspar","SC").
                    build();
            fornecedorController.cadastrar(f2);
        } catch (Exception e){
            e.printStackTrace();
        }



        System.out.println();
    }
}









