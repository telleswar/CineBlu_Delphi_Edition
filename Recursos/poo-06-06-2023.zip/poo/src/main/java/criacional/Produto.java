package criacional;

import java.util.Date;
//https://shorturl.at/iBGQ1

public class Produto {
    enum Categoria{
        ALIMENTO, LAZER, ELETRONICO, BEBIDA, VESTUARIO, OUTROS
    }
    private int id;
    private String descricao;
    private Categoria categoria;
    private Float peso;
    private Date validade;
    private Float quantidade;
    private Float preco;
    private Fornecedor fornecedor;
}
