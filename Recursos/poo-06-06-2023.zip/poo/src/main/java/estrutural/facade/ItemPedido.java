package estrutural.facade;
public class ItemPedido {
    double quantidade;
    Produto produto;
    public ItemPedido(double quantidade, Produto produto) {
        this.quantidade = quantidade;
        this.produto = produto;
    }
    public double calculaTotal(){
        return quantidade*produto.valor;
    }

}
