package estrutural.facade;

public class Produto {
    String descricao;
    double valor;

    public Produto(String descricao, double valor) {
        this.descricao = descricao;
        this.valor = valor;
    }
}
