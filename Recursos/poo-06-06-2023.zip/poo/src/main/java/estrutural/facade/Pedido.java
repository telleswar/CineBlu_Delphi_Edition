package estrutural.facade;

import java.util.ArrayList;
import java.util.List;

public class Pedido {
    List<ItemPedido> itens = new ArrayList<>();
    public double calculaTotal(){
        double total=0;
        for(ItemPedido item: itens){
            total+=item.calculaTotal();
        }
        return total;
    }
}
