package estrutural.facade;

public class PedidoFacade {
    Pedido pedido = new Pedido();
    Pagamento pagamento = new Pagamento();
    Entrega entrega = new Entrega();
    public void adicionarProduto(double quantidade, Produto produto){
        pedido.itens.add(new ItemPedido(quantidade, produto));
    }
    public double calculaTotal(){
        return pedido.calculaTotal();
    }
    public void mostrarPedido(){
        System.out.println("---PEDIDO---");
        System.out.println("Descricao\tQtd\tUnit\tTotal");
        for (ItemPedido item: pedido.itens) {
            System.out.printf("- %s\t%s\t%.2f\t%.2f\n",
                    item.produto.descricao,
                    item.quantidade,
                    item.produto.valor,
                    item.calculaTotal());
        }
        System.out.printf("\t\t\t%.2f\n",calculaTotal());
    }
    public void finalizar(String endereco){
        System.out.println("Finalizando compra");
        boolean res=pagamento.processaPagamento(calculaTotal());
        if(res){
            System.out.println("Compra efetuada");
            System.out.println("Valor: " + calculaTotal());
            entrega.efetuaEntrega(endereco);
        }
    }



}
