package estrutural.facade;

public class Entrega {
    public void efetuaEntrega(String endereco){
        System.out.println("Entregando no endereço: " + endereco);
    }
}
