package estrutural.facade;

public class Main {
    public static void main(String[] args) {
        Produto p1 = new Produto("Camiseta",24.9);
        Produto p2 = new Produto("Calça",50.5);
        Produto p3 = new Produto("Cinto",32.90);

        PedidoFacade facade = new PedidoFacade();
        facade.adicionarProduto(2,p1);
        facade.adicionarProduto(1,p2);
        facade.adicionarProduto(2,p3);
        facade.mostrarPedido();
        facade.finalizar("IFSC Campus Gaspar - Lab6!");



    }
}
