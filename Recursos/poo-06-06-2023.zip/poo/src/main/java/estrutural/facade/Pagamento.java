package estrutural.facade;

public class Pagamento {
    public boolean processaPagamento(double valor){
        //regra simples de processamento
        if(valor>0){
            System.out.println("Efetuando pagamento: " + valor);
            return true;
        }
        return false;
    }
}
