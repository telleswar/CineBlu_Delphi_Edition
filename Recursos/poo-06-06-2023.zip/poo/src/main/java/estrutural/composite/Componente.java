package estrutural.composite;

public interface Componente {
    public void detalhar();
    public double calcularPreco();
}
