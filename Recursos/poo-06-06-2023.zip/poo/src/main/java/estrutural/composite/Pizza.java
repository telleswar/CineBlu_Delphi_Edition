package estrutural.composite;

public class Pizza implements Componente{
    String nome;
    double preco;
    public Pizza(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }
    @Override
    public void detalhar() {
        System.out.printf("Pizza: %s\t%.2f\n",nome,preco);
    }
    @Override
    public double calcularPreco() {
        return preco;
    }
}
