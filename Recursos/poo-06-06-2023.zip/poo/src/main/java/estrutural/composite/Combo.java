package estrutural.composite;

import java.util.ArrayList;
import java.util.List;

public class Combo implements Componente{
    String nome;
    List<Componente> componentes = new ArrayList<>();
    public Combo(String nome) {
        this.nome = nome;
    }
    public void adicionarComponente(Componente componente){
        componentes.add(componente);
    }

    @Override
    public void detalhar() {
        System.out.println("Nome do combo: " +nome);
        for(Componente comp: componentes){
            comp.detalhar();
        }
        System.out.printf("Total: %.2f\n",calcularPreco());
    }
    @Override
    public double calcularPreco() {
        double total=0;
        for(Componente comp: componentes){
            total+=comp.calcularPreco();
        }
        return total*0.9;
    }
}
