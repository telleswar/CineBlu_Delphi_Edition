package estrutural.composite;

public class Main {
    public static void main(String[] args) {
        Componente pizzaCalabresa = new Pizza("Calabresa",79);
        Componente pizzaFrango = new Pizza("Frango",82);
        Componente pizzaMarguerita = new Pizza("Marguerita",70);
        Componente cocaZero2L = new Refrigerante("Coca Zero 2L",18);
        Componente laranjinha = new Refrigerante("Laranjinha",10);
        Componente fritas = new Fritas("Fritas Média",25);

        Combo combo1 = new Combo("Combo Família - Casal");
        combo1.adicionarComponente(pizzaCalabresa);
        combo1.adicionarComponente(cocaZero2L);
        combo1.adicionarComponente(fritas);

        Combo combo2 = new Combo("Combo Família Esganada");
        combo2.adicionarComponente(pizzaCalabresa);
        combo2.adicionarComponente(pizzaFrango);
        combo2.adicionarComponente(pizzaMarguerita);
        combo2.adicionarComponente(cocaZero2L);
        combo2.adicionarComponente(laranjinha);
        combo2.adicionarComponente(fritas);
        combo2.adicionarComponente(fritas);

        Combo combo3 = new Combo("Combo Família TURBO");
        combo3.adicionarComponente(combo1);
        combo3.adicionarComponente(combo2);
        combo3.adicionarComponente(combo2);

        combo3.detalhar();
    }
}
