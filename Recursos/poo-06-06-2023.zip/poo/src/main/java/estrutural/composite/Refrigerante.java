package estrutural.composite;

public class Refrigerante implements Componente{
    public Refrigerante(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    String nome;
    double preco;

    @Override
    public void detalhar() {
        System.out.printf("Refrigerante: %s\t%.2f\n",nome,preco);
    }

    @Override
    public double calcularPreco() {
        return preco;
    }
}
