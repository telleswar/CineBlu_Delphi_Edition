package estrutural.composite;

public class Fritas implements Componente{
    public Fritas(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    String nome;
    double preco;

    @Override
    public void detalhar() {

        System.out.printf("Fritas: %s\t%.2f\n",nome,preco);
    }

    @Override
    public double calcularPreco() {
        return preco;
    }
}
