package estrutural.adapter;

public class StringToDoubleAdaptador
    implements DoubleConverter{
    private StringConverter conversor = new StringConverter();

    @Override
    public double converter(String txt) {
        txt = txt.replace(',','.');
        return conversor.converterParaDouble(txt);
    }
}
