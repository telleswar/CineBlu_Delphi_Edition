package estrutural.adapter;

public class StringConverter {
    public double converterParaDouble(String txt){
        return Double.parseDouble(txt);
    }
}
