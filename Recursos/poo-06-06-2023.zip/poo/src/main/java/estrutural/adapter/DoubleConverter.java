package estrutural.adapter;

public interface DoubleConverter {
    public double converter(String txt);

}
