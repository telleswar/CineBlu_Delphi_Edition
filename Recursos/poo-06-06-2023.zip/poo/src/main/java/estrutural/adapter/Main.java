package estrutural.adapter;

public class Main {
    public static void main(String[] args) {
        DoubleConverter conversor = new StringToDoubleAdaptador();
        String txt = "1,14";
        System.out.println("Número convertido: " +
                conversor.converter(txt));

    }
}
