package br.edu.ifsc.exemplo;

public class CD extends AbstractOpticMedia{

    public CD(String descricao,
              int duracao,
              String nomeArtista,
              String nomeAlbum){
        super(descricao, duracao, nomeArtista, nomeAlbum);
    }


}
