package br.edu.ifsc.exemplo;

public abstract class AbstractMagneticMedia extends
AbstractMedia{
    public AbstractMagneticMedia(String descricao,
                              int duracao,
                              String nomeArtista,
                              String nomeAlbum)
    {
        super(descricao, duracao, nomeArtista, nomeAlbum);
    }
    @Override
    public final MediaType getType() {
        return MediaType.MAGNETIC;
    }
}
