package br.edu.ifsc.exemplo;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String nomeArtista;
        String descricao;
        int totalDuracao;
        String nomeAlbum;
        AbstractMedia media = null;
        System.out.println("Qual o nome do artista?");
        nomeArtista=scanner.nextLine();
        System.out.println("Qual a descricao desta mídia?");
        descricao=scanner.nextLine();
        System.out.println("Qual a duração em segundos?");
        totalDuracao = Integer.parseInt(scanner.nextLine());
        System.out.println("Qual o nome do album?");
        nomeAlbum=scanner.nextLine();

        System.out.println("Qual o tipo de media?");
        System.out.println("1 - CD");
        System.out.println("2 - DVD");
        System.out.println("3 - MP3");
        int tipo = Integer.parseInt(scanner.nextLine());
        if(tipo==1){
            media = new CD(descricao,totalDuracao,nomeArtista,nomeAlbum);
        }else if (tipo==2){
            media = new DVD(descricao,totalDuracao,nomeArtista,nomeAlbum);
        }else if (tipo==3){
            media = new MP3(descricao,totalDuracao,nomeArtista,nomeAlbum);
        }

        System.out.println(media);
        Player player = new Player();
        player.addMedia(media);
        player.addMedia(new CD("PJ", 120, "Pearl Jam","Album2"));

        player.play();
        player.next();
        player.next();
        player.next();
        player.pause();
        player.next();
        player.previous();





    }
}
