package br.edu.ifsc.exemplo;

public abstract class AbstractOpticMedia
    extends AbstractMedia{
    public AbstractOpticMedia(String descricao,
                         int duracao,
                         String nomeArtista,
                         String nomeAlbum)
    {
        super(descricao, duracao, nomeArtista, nomeAlbum);
    }
    @Override
    public final MediaType getType() {
        return MediaType.OPTIC;
    }
}
