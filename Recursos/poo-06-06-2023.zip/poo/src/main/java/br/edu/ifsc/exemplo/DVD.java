package br.edu.ifsc.exemplo;

public class DVD extends AbstractOpticMedia{
    public DVD(String descricao,
              int duracao,
              String nomeArtista,
              String nomeAlbum){
        super(descricao, duracao, nomeArtista, nomeAlbum);
    }
}
