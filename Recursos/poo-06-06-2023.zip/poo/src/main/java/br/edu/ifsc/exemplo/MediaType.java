package br.edu.ifsc.exemplo;

public enum MediaType {
    OPTIC("Ótico"), MAGNETIC("Magnético");
    private String description;
    MediaType(String desc){
        this.description=desc;
    }

    @Override
    public String toString() {
        return this.description;
    }
}
