package br.edu.ifsc.exemplo;

public abstract class AbstractMedia {
    String descricao;
    int duracao;
    String nomeArtista;
    String nomeAlbum;


    public AbstractMedia(String descricao,
                         int duracao,
                         String nomeArtista,
                         String nomeAlbum) {
        this.descricao = descricao;
        this.duracao = duracao;
        this.nomeArtista = nomeArtista;
        this.nomeAlbum = nomeAlbum;
    }


    public abstract MediaType getType();

    @Override
    public String toString() {
        return String.format("Nome: %s\nDescrição:%s\nDuração:%s (segundos)\nAlbum: %s\n" +
                        "Tipo mídia: %s",
                nomeArtista, descricao,duracao, nomeAlbum, getType());
    }
}
