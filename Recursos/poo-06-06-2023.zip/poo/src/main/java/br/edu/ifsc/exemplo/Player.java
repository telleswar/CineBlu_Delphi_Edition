package br.edu.ifsc.exemplo;

import java.util.ArrayList;
import java.util.LinkedList;

public class Player {
    LinkedList<AbstractMedia> medias = new LinkedList<>();
    int actual=0;
    public void addMedia(AbstractMedia media){
        medias.add(media);
    }
    public void removeMedia(AbstractMedia media){
        medias.remove(media);
    }

    public void play(){
        System.out.println("Playing: " + medias.get(actual));
    }
    public void pause(){
        System.out.println("Pausing: " + medias.get(actual));
    }
    public void next(){
        System.out.println("Next music");
        actual++;
        if(actual>=medias.size()){
            actual=0;
        }
        play();
    }
    public void previous(){
        System.out.println("Previous music");
        actual--;
        if(actual<0){
            actual = medias.size()-1;
        }
        play();
    }
}
