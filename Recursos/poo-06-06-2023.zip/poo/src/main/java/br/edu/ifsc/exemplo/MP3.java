package br.edu.ifsc.exemplo;

public class MP3 extends AbstractMagneticMedia{
    public MP3(String descricao,
               int duracao,
               String nomeArtista,
               String nomeAlbum){
        super(descricao, duracao, nomeArtista, nomeAlbum);
    }
}
