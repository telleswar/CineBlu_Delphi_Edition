package comportamental.template;

class PagamentoPessoaJuridica extends PagamentoTemplate {
    private double imposto1=0;
    private double imposto2=0;
    public PagamentoPessoaJuridica(){
        super("Pessoa Juridica");
    }
    protected double calcularTributo(double valor) {
        imposto1 = valor*0.05;
        imposto2 = valor*0.10;
        return imposto1+imposto2;
    }

    @Override
    protected String detalheImposto() {

        return String.format("Imposto 1 (5%%): %.2f\nImposto 2 (10%%): %.2f",imposto1, imposto2);
    }
}
