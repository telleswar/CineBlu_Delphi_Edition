package comportamental.template;

public class Main {
    public static void main(String[] args) {
        PagamentoTemplate pagamentoPF = new PagamentoPessoaFisica();
        pagamentoPF.realizarPagamento(1000); // Pessoa física: 5% de tributo

        PagamentoTemplate pagamentoPJ = new PagamentoPessoaJuridica();
        pagamentoPJ.realizarPagamento(1000); // Pessoa jurídica: 15% de tributo
    }
}
