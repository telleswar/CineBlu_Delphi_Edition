package comportamental.state;

class MarchaRe implements EstadoMarcha {
    private Carro carro;

    public MarchaRe(Carro carro) {
        this.carro = carro;
    }

    @Override
    public void subirMarcha() {
        System.out.println("Não é possível subir para uma marcha superior à Ré");
    }

    @Override
    public void descerMarcha() {
        System.out.println("Não é possível descer para uma marcha inferior à Ré");
    }

    @Override
    public void engatarRe() {
        System.out.println("Já está na marcha Ré");
    }
}