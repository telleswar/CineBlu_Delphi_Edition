package comportamental.state;

interface EstadoMarcha {
    void subirMarcha();
    void descerMarcha();
    void engatarRe();
}