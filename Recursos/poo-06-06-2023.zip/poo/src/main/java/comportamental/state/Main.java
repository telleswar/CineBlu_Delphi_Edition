package comportamental.state;

public class Main {
    public static void main(String[] args) {
        Carro carro = new Carro();
        carro.subirMarcha();
        carro.ligar();
        carro.engatarNeutro();
        carro.ligar();
        carro.subirMarcha();
        carro.subirMarcha();
        carro.subirMarcha();
        carro.subirMarcha();
        carro.subirMarcha();
        carro.subirMarcha();
        carro.engatarRe();
        carro.engatarNeutro();
        carro.engatarRe();
        carro.desligar();
    }
}
