package comportamental.state;

class Carro {
    private EstadoMarcha estadoMarcha;
    private MarchaNeutro marchaNeutro;
    private Marcha1 marcha1;
    private Marcha2 marcha2;
    private Marcha3 marcha3;
    private Marcha4 marcha4;
    private Marcha5 marcha5;
    private MarchaRe marchaRe;

    public Carro() {
        marchaNeutro = new MarchaNeutro(this);
        marcha1 = new Marcha1(this);
        marcha2 = new Marcha2(this);
        marcha3 = new Marcha3(this);
        marcha4 = new Marcha4(this);
        marcha5 = new Marcha5(this);
        marchaRe = new MarchaRe(this);

        estadoMarcha = marchaNeutro;
    }

    public EstadoMarcha getEstadoMarcha() {
        return estadoMarcha;
    }

    public void setEstadoMarcha(EstadoMarcha estadoMarcha) {
        this.estadoMarcha = estadoMarcha;
    }

    public MarchaNeutro getMarchaNeutro() {
        return marchaNeutro;
    }

    public Marcha1 getMarcha1() {
        return marcha1;
    }

    public Marcha2 getMarcha2() {
        return marcha2;
    }

    public Marcha3 getMarcha3() {
        return marcha3;
    }

    public Marcha4 getMarcha4() {
        return marcha4;
    }

    public Marcha5 getMarcha5() {
        return marcha5;
    }

    public MarchaRe getMarchaRe() {
        return marchaRe;
    }

    public void ligar() {
        if (estadoMarcha instanceof MarchaNeutro) {
            System.out.println("Carro ligado - VRUMMMMMM");
        } else {
            System.out.println("O carro precisa estar na marcha Neutro (N) para ser ligado");
        }
    }

    public void desligar() {
        System.out.println("Carro desligado");
        estadoMarcha = marchaNeutro;
    }

    public void subirMarcha() {
        estadoMarcha.subirMarcha();
    }

    public void descerMarcha() {
        estadoMarcha.descerMarcha();
    }

    public void engatarRe() {
        estadoMarcha.engatarRe();
    }
    public void engatarNeutro(){
        estadoMarcha = marchaNeutro;
    }
}