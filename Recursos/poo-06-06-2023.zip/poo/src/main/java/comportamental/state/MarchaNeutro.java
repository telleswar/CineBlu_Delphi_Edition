package comportamental.state;

class MarchaNeutro implements EstadoMarcha {
    private Carro carro;

    public MarchaNeutro(Carro carro) {
        this.carro = carro;
    }

    @Override
    public void subirMarcha() {
        System.out.println("Subindo para a marcha 1");
        carro.setEstadoMarcha(carro.getMarcha1());
    }

    @Override
    public void descerMarcha() {
        System.out.println("Descendo para a marcha Ré");
        carro.setEstadoMarcha(carro.getMarchaRe());
    }

    @Override
    public void engatarRe() {
        System.out.println("Engatando marcha Ré");
        carro.setEstadoMarcha(carro.getMarchaRe());
    }
}
