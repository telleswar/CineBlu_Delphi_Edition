package comportamental.state;

class Marcha3 implements EstadoMarcha {
    private Carro carro;

    public Marcha3(Carro carro) {
        this.carro = carro;
    }

    @Override
    public void subirMarcha() {
        System.out.println("Subindo para a marcha 4");
        carro.setEstadoMarcha(carro.getMarcha4());
    }

    @Override
    public void descerMarcha() {
        System.out.println("Descendo para a marcha 2");
        carro.setEstadoMarcha(carro.getMarcha2());
    }

    @Override
    public void engatarRe() {
        System.out.println("Não é possível engatar marcha Ré diretamente da marcha 3");
    }
}