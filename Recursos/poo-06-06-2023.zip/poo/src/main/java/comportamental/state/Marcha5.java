package comportamental.state;

class Marcha5 implements EstadoMarcha {
    private Carro carro;

    public Marcha5(Carro carro) {
        this.carro = carro;
    }

    @Override
    public void subirMarcha() {
        System.out.println("Não é possível subir para uma marcha superior à marcha 5");
    }

    @Override
    public void descerMarcha() {
        System.out.println("Descendo para a marcha 4");
        carro.setEstadoMarcha(carro.getMarcha4());
    }

    @Override
    public void engatarRe() {
        System.out.println("Não é possível engatar marcha Ré diretamente da marcha 5");
    }
}