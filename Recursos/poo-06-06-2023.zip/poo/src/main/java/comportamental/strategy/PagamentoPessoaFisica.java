package comportamental.strategy;

class PagamentoPessoaFisica extends PagamentoTemplate {

    private double imposto=0;
    public PagamentoPessoaFisica(){
        super("Pessoa Fisica");
    }
    protected double calcularTributo(double valor) {
        this.imposto = valor * 0.05;
        return this.imposto;
    }
    protected String detalheImposto() {
        return String.format("Imposto (5%%):  %.2f",imposto);
    }
}