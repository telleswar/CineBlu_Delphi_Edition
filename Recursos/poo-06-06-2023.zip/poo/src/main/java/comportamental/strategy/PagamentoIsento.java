package comportamental.strategy;

public class PagamentoIsento implements PagamentoStrategy{
    @Override
    public void realizarPagamento(double valor) {
        System.out.println("Pagamento isento");
        System.out.printf("Valor: %.2f\n",valor);
        System.out.printf("Valor total: %.2f",valor);
    }
}
