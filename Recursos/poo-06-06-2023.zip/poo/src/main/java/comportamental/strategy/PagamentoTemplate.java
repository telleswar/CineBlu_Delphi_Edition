package comportamental.strategy;

abstract class PagamentoTemplate implements PagamentoStrategy{
    private String tipo;
    public PagamentoTemplate(String tipo){
        this.tipo=tipo;
    }
    public final void realizarPagamento(double valor) {
        System.out.println("Pagamento para "+tipo);
        double valorComTributo = valor + calcularTributo(valor);
        System.out.printf("Pagamento = %.2f\n",valor);
        System.out.println("Detalhe imposto");
        System.out.println("_____________");
        System.out.println(detalheImposto());
        System.out.println("_____________");
        System.out.println("Valor do pagamento: R$ " + valorComTributo);
    }

    protected abstract double calcularTributo(double valor);
    protected abstract String detalheImposto();
}