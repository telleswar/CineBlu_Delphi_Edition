package comportamental.strategy;

public class Main {
    public static void main(String[] args) {
        PagamentoContext contexto = new PagamentoContext();

        contexto.setStrategy(new PagamentoPessoaFisica());
        contexto.realizarPagamento(1000.00);

        contexto.setStrategy(new PagamentoPessoaJuridica());
        contexto.realizarPagamento(1000.00);

        contexto.setStrategy(new PagamentoIsento());
        contexto.realizarPagamento(1000);

        contexto.setStrategy(new PagamentoPix());
        contexto.realizarPagamento(1000);

    }
}