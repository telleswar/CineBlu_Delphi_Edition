package comportamental.strategy;

public class PagamentoPix implements PagamentoStrategy{


    @Override
    public void realizarPagamento(double valor) {
        System.out.println("Pagamento pix");
        System.out.println("Gerando QRCode");
        System.out.println("Pix de : " + valor);
    }
}
