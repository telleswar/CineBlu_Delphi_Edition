package comportamental.strategy;

class PagamentoContext {
    private PagamentoStrategy strategy;

    public void setStrategy(PagamentoStrategy strategy) {
        this.strategy = strategy;
    }

    public void realizarPagamento(double valor) {
        strategy.realizarPagamento(valor);
    }
}