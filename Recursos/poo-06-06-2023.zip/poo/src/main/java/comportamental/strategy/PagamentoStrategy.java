package comportamental.strategy;

public interface PagamentoStrategy {
    void realizarPagamento(double valor);
}
