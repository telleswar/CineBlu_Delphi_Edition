package org.example;

public class Calculadora {
    int a,b,c;
    int[] valores;
    public Calculadora(int a, int b, int c){
        System.out.println("Construtor A");
        this.a = a;
        this.b = b;
        this.c = c;
        System.out.println("Total A: " + getTotal());
        valores = new int[]{a,b,c};
    }
    public Calculadora(int... valores){
        System.out.println("Construtor B");
        this.valores = valores;
        int total = 0;
        for (int val: valores) {
            total+=val;
        }
        System.out.println("Total B: " + total);
    }

    public int getTotal(){
        return a+b+c;
    }

    public int getTotalArray(){
        int total = 0;
        for (int val: valores) {
            total+=val;
        }
        return total;
    }
    public static void main(String[] args) {
        Calculadora calc1 = new Calculadora(1,2,3);
        Calculadora calc2 = new Calculadora(new int[]{1,3,4,5});
        Calculadora calc3 = new Calculadora(1,3,4,5);
        Calculadora calc4 = new Calculadora(1,3,4,5);
        System.out.println("Calc1" + calc1.getTotal());
        System.out.println("Calc1" + calc1.getTotalArray());

    }
}
