package org.example;

import br.edu.ifsc.exemplo.MediaType;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        System.out.println("Teste POO");

        for(MediaType e: MediaType.values()){
            System.out.println(e);
        }
    }
} 
